package com.capgemini.capstore.dao;

public interface ICouponDao {

	public double applyCoupons(String couponCode, double price) ;
}